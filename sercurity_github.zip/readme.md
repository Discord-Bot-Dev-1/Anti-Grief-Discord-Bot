
Anti-Grief-Discord-Bot

(EN) First of all: Please unzip the file.

(DE/GE) Zuerst: Entpacke bitte die Datei.

English: This bot is actually only intended for German servers. If you are not a German server, you can still use the 
bot. Simply replace the messages in lines 33, 31 and 26 with any other text. Attention! Just replace the text in the 
"for example on line 26 like this: msg.reply (" I was hacked): I'm going now! <@ "+ ownerfromdiscord +"> ");. In lines 
14,15 and 16 you only have to adjust your variables.

Deutsch/German: Bitte lese dir in der index.js Linie 1-12 durch.
