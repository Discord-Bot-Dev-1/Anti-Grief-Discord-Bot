/*
        **Anti Discord @everyone / @here Grief Bot**

Dieser Bot ist entwickelt von DISCORD Bot Developer#5857 Discord ID: 707474984678719548 Email: discordbotdev@gmx.de 
Brauchst du Hilfe? Kontaktiere mich gerne. :)
Wenn ein User öfters als 5x die Stunde @everyone oder @here macht wird er vom Server gebannt, um vor Griefs zu schützen.
Möchtest du die Zeit ändern in dem Zeitraum man nur 5x @everyone/@here machen darf, so musst du nur die Variable (ganz oben) time ändern. (1000 = 1Sekunden, ohne Einheit!)
Bitte gebe in der Variable ownerfromdiscord deine ID ein.
Außerdem schreibe bitte in bottoken deinen Bottoken rein.

License: GNU AFFERO GENERAL PUBLIC LICENSE v 3.0
*/
const bottoken = "your bot token here"; 
const time = 3600000; //1secound = 1000
const ownerfromdiscord = "123"//replace 123 with your Discord ID.
const Discord = require('discord.js')  //Frage Discord ab.
var client =  new Discord.Client()
client.on('ready', function(){
    console.log("I am ready!");
});
const check = []; //Definiere die Variable check
client.on('message', (msg) => { //Wenn eine Nachricht geschrieben wird
if(msg.mentions.everyone){ //Wenn die Nachricht @everyone / @here enthält
  if(!check[msg.author.id]) check[msg.author.id] = 0; //Wenn der User noch nicht @everyone/@here erwähnt hat setze check auf 0 für den User.
  if(msg.author.id === botid){ //Wenn der Bot @everyone erwähnt
    msg.reply("Ich wurde gehackt ): Ich gehe jetzt! <@"+ownerfromdiscord+">"); //Schreibe eine Nachricht.
    return guild.leave(); //Verlasse den Server und breche ab.
  }
  check[msg.author.id] = check[msg.author.id] + 1; //Setze den @everyone count für den Nutzer auf +1:
if(check[msg.author.id] >= 5){ //Wenn man öfters als 5mal @everyone gemacht hat.
  msg.author.send("Du hast zu oft @everyone erwähnt und wurdest deshalb gebannt."); //Sende dem User eine 
Privatnachricht
  client.users.cache.get(ownerfromdiscord).send("Der User mit der ID: "+msg.author.id+" wurde gebannt."); //Sende Tomic R. eine Privatnachricht.
}
  setTimeout(() => { //Setze eine Pause für 1 Stunde (siehe 2 Zeilen weiter unter  }, 3600000);)
  check[msg.author.id] = check[msg.author.id] - 1; //Setze den @everyone/@here Count auf -1.
  }, time);
} 
});
client.login(bottoken);//Logge dich mit deinem Bottoken ein.
